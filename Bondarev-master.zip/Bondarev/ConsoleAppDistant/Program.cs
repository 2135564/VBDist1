﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//string path = @"E:\CL\S8131\text.txt";
Console.WriteLine("Введите путь к текстовому файлу.");
string path = Console.ReadLine();


string str;
FileReading(path);
TakingPercantage(MakingString(str));


void FileReading(string path)
{
    using (StreamReader sr = new StreamReader(path))
    {
        str = sr.ReadToEnd();
    }
}

List<string> MakingString(string str)
{
    List<string> words = new List<string>();
    StringBuilder word = new StringBuilder();
    foreach (var item in str)
    {
        if ((Convert.ToString(item) == " ") || (Convert.ToString(item) == ",") || (Convert.ToString(item) == ".")
            || (Convert.ToString(item) == "\t") || (Convert.ToString(item) == "?") || (Convert.ToString(item) == "!"))
        {
            words.Add(word.ToString());
            word.Clear();
        }
        else
        {
            word.Append(item);
        }
    }
    
    return(words);
}

void TakingPercantage(List<string> words)
{
    const string ruVowels = "АаЕеЁёИиОоУуЫыЭэЮюЯя";
    decimal maxPercent = 0;
    string maxPercentWord = "";

    foreach (var item in words)
    {
        decimal k = 0;
        decimal kV = 0;

        foreach (var letter in item)
        {
            k += 1;
            if (ruVowels.Contains(letter))
            {
                kV += 1;
            }

        }

        try
        {
            decimal currectPercent = kV / k;
            if (currectPercent > maxPercent)
            {
                maxPercent = currectPercent;
                maxPercentWord = item;
            }
        }
        catch
        {

        }
       
    }
    string Percantage = string.Format("{0:0.00}", maxPercent * 100) + "%";

    Console.WriteLine(maxPercentWord + " " + Percantage);   
}
