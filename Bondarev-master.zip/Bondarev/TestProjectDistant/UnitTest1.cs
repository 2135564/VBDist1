using Xunit;

namespace TestProjectDistant
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}